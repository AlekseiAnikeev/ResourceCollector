using UnityEngine;

public class FollowObject : MonoBehaviour
{
    public Transform target;
    public Vector3 positionOffset = new Vector3(0, 2f, 0);

    void LateUpdate()
    {
        if(target != null)
        {
            // Обновляем только позицию, не затрагивая вращение
            transform.position = target.position + positionOffset;
        }
    }
}