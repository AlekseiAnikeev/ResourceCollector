using UnityEngine;
using System.Collections.Generic;

public class ResourceSpawner : MonoBehaviour
{
    public GameObject resourcePrefab;
    public float spawnRadius = 50f;
    public float spawnInterval = 10f;
    public int poolSize = 20;
    
    private Queue<Resource> resourcePool = new Queue<Resource>();
    private List<Resource> activeResources = new List<Resource>();

    void Start()
    {
        InitializePool();
        InvokeRepeating(nameof(SpawnResource), 0f, spawnInterval);
    }

    void InitializePool()
    {
        for (int i = 0; i < poolSize; i++)
        {
            GameObject obj = Instantiate(resourcePrefab, Vector3.zero, Quaternion.identity);
            Resource resource = obj.GetComponent<Resource>();
            resource.resourceSpawner = this;
            obj.SetActive(false);
            resourcePool.Enqueue(resource);
        }
    }

    void SpawnResource()
    {
        if (resourcePool.Count > 0)
        {
            Resource resource = resourcePool.Dequeue();
            resource.transform.position = GetRandomPosition();
            resource.gameObject.SetActive(true);
            resource.isCollected = false;
            resource.isTargeted = false;
            activeResources.Add(resource);
        }
    }

    Vector3 GetRandomPosition()
    {
        Vector3 pos = transform.position + Random.insideUnitSphere * spawnRadius;
        pos.y = 0;
        return pos;
    }

    public void ReturnResource(Resource resource)
    {
        resource.gameObject.SetActive(false);
        activeResources.Remove(resource);
        resourcePool.Enqueue(resource);
    }

    public List<Resource> GetActiveResources() => activeResources;
}