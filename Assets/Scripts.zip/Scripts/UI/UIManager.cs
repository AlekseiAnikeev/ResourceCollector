using TMPro;
using UnityEngine;

namespace UI
{
    public class UIManager : MonoBehaviour
    {
        [SerializeField] private TMP_Text resourcesText;

        public void UpdateResourcesUI(int amount)
        {
            resourcesText.text = $"Кристалов: {amount}";
        }
    }
}