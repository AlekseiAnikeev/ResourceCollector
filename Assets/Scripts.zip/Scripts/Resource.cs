using UnityEngine;

public class Resource : MonoBehaviour
{
    public bool isCollected;
    public bool isTargeted;
    public ResourceSpawner resourceSpawner;

    public void MarkAsTargeted() => isTargeted = true;

    public void Collect()
    {
        if (isCollected || resourceSpawner == null) return;
        
        isCollected = true;
        resourceSpawner.ReturnResource(this);
    }
}