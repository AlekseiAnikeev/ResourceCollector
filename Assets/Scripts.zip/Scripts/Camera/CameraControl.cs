using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Camera
{
    [RequireComponent(typeof(PlayerInput))]
    public class CameraControl : MonoBehaviour
    {
        [Header("Основное")] 
        [SerializeField] private Transform _cameraTransform;

        [Header("Выбор управления")] 
        [SerializeField] private bool _moveWithKeyboad;
        [SerializeField] private bool _moveWithEdgeScrolling;

        [Header("Управление клавиатурой")] 
        [SerializeField] private float _fastSpeed = 0.05f;
        [SerializeField] private float _normalSpeed = 0.01f;
        [SerializeField] private float _movementSensitivity = 1f;

        [Header("Управление мышью")] 
        [SerializeField] private float _edgeSize = 50f;

        [Header("Текстуры курсора")] 
        [SerializeField] private Texture2D _cursorArrowUp;

        [SerializeField] private Texture2D _cursorArrowDown;
        [SerializeField] private Texture2D _cursorArrowLeft;
        [SerializeField] private Texture2D _cursorArrowRight;

        private Vector3 _newPosition;
        private Vector3 _dragStartPosition;
        private Vector3 _dragCurrentPosition;

        private PlayerInput _playerInput;
        private InputAction _moveAction;
        private InputAction _speedModifierAction;

        private float _movementSpeed;
        private bool _isCursorSet = false;

        private CursorArrow _currentCursor = CursorArrow.DEFAULT;


        private void Awake()
        {
            _playerInput = GetComponent<PlayerInput>();
            _moveAction = _playerInput.actions["Move"];
            _speedModifierAction = _playerInput.actions["SpeedModifier"];
        }

        private void Start()
        {
            _newPosition = transform.position;
            _movementSpeed = _normalSpeed;
        }

        private void Update()
        {
            HandleCameraMovement();
        }

        private void HandleCameraMovement()
        {
            if (_moveWithKeyboad)
            {
                _movementSpeed = _speedModifierAction.IsPressed() ? _fastSpeed : _normalSpeed;

                Vector2 moveInput = _moveAction.ReadValue<Vector2>();
                
                _newPosition += transform.forward * (_movementSpeed * moveInput.y);
                _newPosition += transform.right * (_movementSpeed * moveInput.x);
            }
            
            if (_moveWithEdgeScrolling)
            {
                Vector2 mousePos = Mouse.current.position.ReadValue();
                
                if (mousePos.x > Screen.width - _edgeSize)
                {
                    _newPosition += (transform.right * _movementSpeed);
                    
                    ChangeCursor(CursorArrow.RIGHT);
                    
                    _isCursorSet = true;
                } 
                else if (mousePos.x < _edgeSize)
                {
                    _newPosition += (transform.right * -_movementSpeed);
                    
                    ChangeCursor(CursorArrow.LEFT);
                    
                    _isCursorSet = true;
                } 
                else if (mousePos.y > Screen.height - _edgeSize)
                {
                    _newPosition += (transform.forward * _movementSpeed);
                    
                    ChangeCursor(CursorArrow.UP);
                    
                    _isCursorSet = true;
                } 
                else if (mousePos.y < _edgeSize)
                {
                    _newPosition += (transform.forward * -_movementSpeed);
                    
                    ChangeCursor(CursorArrow.DOWN);
                    
                    _isCursorSet = true;
                }
                else
                {
                    if (_isCursorSet)
                    {
                        ChangeCursor(CursorArrow.DEFAULT);
                        
                        _isCursorSet = false;
                    }
                }
            }

            transform.position = Vector3.Lerp(transform.position, _newPosition, Time.deltaTime * _movementSensitivity);
            Cursor.lockState = CursorLockMode.Confined;
        }

        private void ChangeCursor(CursorArrow newCursor)
        {
            if (_currentCursor == newCursor)
                return;

            switch (newCursor)
            {
                case CursorArrow.UP:
                    Cursor.SetCursor(_cursorArrowUp, Vector2.zero, CursorMode.Auto);
                    break;
                
                case CursorArrow.DOWN:
                    Cursor.SetCursor(_cursorArrowDown, new Vector2(_cursorArrowDown.width, _cursorArrowDown.height),
                        CursorMode.Auto);
                    break;
                
                case CursorArrow.LEFT:
                    Cursor.SetCursor(_cursorArrowLeft, Vector2.zero, CursorMode.Auto);
                    break;
                
                case CursorArrow.RIGHT:
                    Cursor.SetCursor(_cursorArrowRight, new Vector2(_cursorArrowRight.width, _cursorArrowRight.height),
                        CursorMode.Auto);
                    break;
                
                case CursorArrow.DEFAULT:
                    Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
                    break;
                
                default:
                    throw new ArgumentOutOfRangeException(nameof(newCursor), newCursor, null);
            }

            _currentCursor = newCursor;
        }
    }
}