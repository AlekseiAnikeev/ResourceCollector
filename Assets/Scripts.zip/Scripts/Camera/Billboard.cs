using UnityEngine;

public class Billboard : MonoBehaviour
{
    private UnityEngine.Camera mainCamera;
    private Quaternion initialRotation;

    void Start()
    {
        mainCamera = UnityEngine.Camera.main;
        initialRotation = transform.rotation;
    }

    void LateUpdate()
    {
        if(mainCamera != null)
        {
            // Сохраняем начальный поворот и добавляем поворот к камере
            transform.rotation = mainCamera.transform.rotation * initialRotation;
        }
    }
}