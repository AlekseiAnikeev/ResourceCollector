using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UI;

public class BaseController : MonoBehaviour
{
    [Header("Settings")]
    public GameObject unitPrefab;
    public int initialUnits = 3;
    public float scanInterval = 5f;
    public float spawnRadius = 3f;

    [Header("Dependencies")]
    public UIManager uiManager;
    public ResourceSpawner resourceSpawner;

    [Header("Effects")]
    public AudioClip deliverySound;
    public ParticleSystem deliveryParticles;

    [Header("Debug")]
    public int availableResources;
    public List<UnitController> allUnits = new List<UnitController>();

    void Start()
    {
        InitializeBase();
        StartCoroutine(ScanRoutine());
    }

    void InitializeBase()
    {
        for (int i = 0; i < initialUnits; i++)
            SpawnUnit();
    }

    void SpawnUnit()
    {
        Vector3 spawnPos = transform.position + Random.insideUnitSphere * spawnRadius;
        spawnPos.y = 0;
        UnitController unit = Instantiate(unitPrefab, spawnPos, Quaternion.identity).GetComponent<UnitController>();
        unit.homeBase = this;
        allUnits.Add(unit);
    }

    IEnumerator ScanRoutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(scanInterval);
            ScanForResources();
        }
    }

    void ScanForResources()
    {
        foreach (Resource resource in resourceSpawner.GetActiveResources())
        {
            if (!resource.isCollected && !resource.isTargeted)
            {
                UnitController freeUnit = allUnits.Find(u => u.isAvailable);
                if (freeUnit != null)
                {
                    freeUnit.AssignResource(resource);
                    return;
                }
            }
        }
    }

    public void DeliverResource()
    {
        availableResources++;
        uiManager.UpdateResourcesUI(availableResources);
        AudioSource.PlayClipAtPoint(deliverySound, transform.position);
        if(deliveryParticles != null) deliveryParticles.Play();
    }
}