using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class UnitController : MonoBehaviour
{
    [Header("Settings")]
    public float collectionDistance = 1f;
    public float collectionDelay = 2f;
    
    [Header("References")]
    public ParticleSystem collectingParticles;
    public LineRenderer pathRenderer;
    public ProgressBar progressBar;

    [Header("Effects")]
    public Animator animator;
    public AudioClip collectSound;

    [HideInInspector] public bool isAvailable = true;
    public BaseController homeBase;
    
    private NavMeshAgent agent;
    private Resource currentTarget;

    void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        pathRenderer.positionCount = 0;
        if(progressBar != null) progressBar.SetVisibility(false);
    }

    public void AssignResource(Resource resource)
    {
        if (!isAvailable) return;

        isAvailable = false;
        currentTarget = resource;
        resource.MarkAsTargeted();
        agent.SetDestination(resource.transform.position);
        
        animator.SetBool("Move",true);
        StartCoroutine(CollectResourceRoutine());
        StartCoroutine(UpdatePathVisualization());
    }

    IEnumerator CollectResourceRoutine()
    {
        while (Vector3.Distance(transform.position, currentTarget.transform.position) > collectionDistance)
            yield return null;

        agent.isStopped = true;
        animator.SetBool("Collect", true);
        
        if(collectingParticles != null)
        {
            collectingParticles.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            collectingParticles.Play();
        }
        
        if(progressBar != null)
        {
            progressBar.SetVisibility(true);
            progressBar.UpdateProgress(0f);
        }

        float timer = 0;
        while(timer < collectionDelay)
        {
            if(currentTarget == null || currentTarget.isCollected) break;
            
            if(progressBar != null)
                progressBar.UpdateProgress(timer / collectionDelay);
            
            timer += Time.deltaTime;
            yield return null;
        }

        if(collectingParticles != null) 
            collectingParticles.Stop(true, ParticleSystemStopBehavior.StopEmitting);
        
        if(progressBar != null)
            progressBar.SetVisibility(false);

        agent.isStopped = false;

        if(currentTarget != null && !currentTarget.isCollected)
        {
            currentTarget.Collect();
            PlayCollectEffects();
            ReturnToBase();
        }
        else
        {
            ResetUnit();
        }
    }

    void ReturnToBase()
    {
        animator.SetBool("Collect", false);
        agent.SetDestination(homeBase.transform.position);
        StartCoroutine(DeliverResourceRoutine());
    }

    IEnumerator DeliverResourceRoutine()
    {
        while (Vector3.Distance(transform.position, homeBase.transform.position) > collectionDistance)
            yield return null;

        homeBase.DeliverResource();
        ResetUnit();
    }

    void ResetUnit()
    {
        isAvailable = true;
        currentTarget = null;
        animator.SetBool("Move", false);
        animator.SetTrigger("Idle");
        pathRenderer.positionCount = 0;
    }

    IEnumerator UpdatePathVisualization()
    {
        while (!isAvailable)
        {
            if (agent.hasPath && agent.path.corners.Length > 0)
            {
                pathRenderer.positionCount = agent.path.corners.Length;
                pathRenderer.SetPositions(agent.path.corners);
            }
            yield return new WaitForSeconds(0.1f);
        }
        pathRenderer.positionCount = 0;
    }
    
    void PlayCollectEffects()
    {
        AudioSource.PlayClipAtPoint(collectSound, transform.position);
    }
}