using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class ProgressBar : MonoBehaviour
{
    [Header("References")]
    public Image fillImage;
    public CanvasGroup canvasGroup;

    [Header("Settings")]
    public float hideDelay = 0.5f;
    
    private Coroutine hideCoroutine;

    void Awake()
    {
        if(canvasGroup == null)
            canvasGroup = GetComponent<CanvasGroup>();
            
        SetVisibility(false);
    }

    public void UpdateProgress(float progress)
    {
        fillImage.fillAmount = Mathf.Clamp01(progress);
        if(hideCoroutine != null) 
            StopCoroutine(hideCoroutine);
    }

    public void SetVisibility(bool visible)
    {
        if(canvasGroup == null) return;
        
        canvasGroup.alpha = visible ? 1 : 0;
        if(visible)
            hideCoroutine = StartCoroutine(HideAfterDelay());
    }

    private IEnumerator HideAfterDelay()
    {
        yield return new WaitForSeconds(hideDelay);
        canvasGroup.alpha = 0;
    }
}